const port = require('./helperfunctions/dynamicport');

const anscConfig = {
    dynamicPort : port
};

module.exports = {anscConfig};