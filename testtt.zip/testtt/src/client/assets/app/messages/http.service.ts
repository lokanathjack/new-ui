import { Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import 'rxjs/Rx';
@Injectable()

export class AuthService {
    constructor(private http: HttpClient) {}

    callAuthService(value: any) {
        const aaf = '/rest/UBMWebUI9/v1/login';
        const body = {
            username: value.username,
            password: value.password
        }
        return this.http.post(aaf,body,{observe: 'body'})
            .map((results) => {
                return results
            })

    }

    getUser(token:string) {
        console.log('getUser function called form httpservice')
        const user = '/rest/UBMWebUI9/v1/user/mike';
        return this.http.get(user,{observe: 'body',headers: new HttpHeaders().set('Authorization',token)})
            .map((result) => {
                return result;
            })

    }


}