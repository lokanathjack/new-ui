import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UbmmainuiComponent } from './ubmmainui.component';

describe('UbmmainuiComponent', () => {
  let component: UbmmainuiComponent;
  let fixture: ComponentFixture<UbmmainuiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UbmmainuiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UbmmainuiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
