import { Injectable } from "@angular/core";

@Injectable()
export class SidDescMenu {
    public sidType: string;
    public requestType: string;
    public sidRestriction: String;
    public sidid: string;

    constructor(){};
    public setSidType(sidType){
        this.sidType=sidType;
    }
    public getSidType(){
        return this.sidType;
    }
    public setRequestType(requestType){
        this.requestType=requestType;
    }
    public getRequestType(){
        return this.requestType;
    }
    public setSidRestriction(sidRestriction){
        this.sidRestriction=sidRestriction;
    }
    public getSidRestriction(){
        return this.sidRestriction;
    }

    public setSidId(sidid){
        this.sidid=sidid;
    }
    public getSidId(){
        return this.sidid;
    }
  }