import { Component, OnInit } from '@angular/core';
import { Http,Response } from '@angular/http';

import { map } from "rxjs/operators";
@Component({
  selector: 'app-mytask',
  templateUrl: './mytask.component.html',
  styleUrls: ['./mytask.component.css']
})
export class MytaskComponent implements OnInit {
 // apiRoot: string = 'https://itunes.apple.com/search';
 apiRoot: string = 'http://zlt17367.vci.att.com:32724/restservices/helloworld/v1/service/myTask?id=2';
 // results: SearchItem[];
  loading: boolean;
  keys: String[];
  valueStr=[];

  constructor(private http: Http) {
  // this.results = [];
    this.loading = false;

   }
httpdata;
  ngOnInit() {

      this.search('Moo');
    // this.obsBooks = this.getBooks();

  // this.getTasks();

   }

 search(term: string) {
    let promise = new Promise((resolve, reject) => {
      //let apiURL = `${this.apiRoot}?term=${term}&media=music&limit=20`;
      let apiURL=`${this.apiRoot}`;
      this.http.get(apiURL)
          .toPromise()
          .then(
              res => { // Success
                this.valueStr = res.json();
              },
              msg => { // Error
                reject(msg);
              }
          );
    });
    return promise;
  }
}


class TaskItem {
  constructor(public dueDate: string,
              public no: string,
              public taskName: string,
              public creator: string,
              public requestType: string,
              public sidId: string,
              public sidDescription: string,
              public requestNumber: string,
              public impactedGroupName: string,
              public assignmentDate: string) {
  }
}



