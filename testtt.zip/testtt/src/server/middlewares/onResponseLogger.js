/**
 * Created by rx226f on 6/25/2018.
 */
const logger= require('@com.att.ajsc/1t-logging').logger;
const updateReqObjWithLogInfo = require('@com.att.ajsc/1t-logging').updateReqObjWithLogInfo;
//------------
const path = require('path');
const fs = require('fs');
const rimraf = require('rimraf');
var configuration;
const dirExist = fs.existsSync(path.resolve(process.cwd(),'config-map'));
const configDirExist = fs.existsSync(path.resolve(process.cwd(),'config'));
const ilib = require('@com.att.ajsc/ilib-nodejs');

if (dirExist) {
    if (configDirExist) {
        rimraf(path.resolve(process.cwd(),'config'),function (err) {
            if (err) {
                logger.info('config folder is not found, it may removed already');
            }else {
                logger.info('config folder removed');
            }
        });
    }
    configuration = require(path.resolve(process.cwd(),'./config-map/override-configs.json'));
}else {
    (function (dir) {
        try {
            fs.statSync(dir);
            logger.info('config-map dir is not exist, config dir exists');
            logger.info('getting configurations from config folder...');
            configuration = require(path.resolve(process.cwd(),'./config/override-configs.json'));
        } catch (e) {
            logger.info('could not get config from config folder');
        }
    })('config');
}
//---------

var onResponseLogger = (req, body) => {
    if( configuration.logging  === '1t-logging') {
        updateReqObjWithLogInfo.preResponse(req, body);
    }
    if( configuration.logging === 'dashboard-logging') {
        dashboardLogger.preResponseHandler(req, body);
    }
}

module.exports = onResponseLogger;

