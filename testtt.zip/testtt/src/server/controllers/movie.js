const {Movie} = require('../models/movies');

const findSuperHero = (req,res) => {
    const findMovie = (searchby,movie) => {
        const m = Movie.find((value) => {
            return value[searchby] === movie;
        });

        return m;
    };

    const superHeroName = req.query.superheroname;
    const superHero = findMovie('title', superHeroName);
    return res.send(superHero);
};

module.exports = {findSuperHero};