var express = require('express');
var router = express.Router();
const logger= require('@com.att.ajsc/1t-logging').logger;
const logConstraints = require('@com.att.ajsc/1t-logging').logConstraints;

/* GET home page. */
router.get('/logtype-request', function(req, res, next) {
    logger.log(logConstraints.LOG_TYPE.REQUEST, logConstraints.LOG_LEVEL.DEBUG, req.path+" route log", req.path+" route pre-response log", [], req);
    res.send("Dynamically changed log level: ");
});

module.exports = router;