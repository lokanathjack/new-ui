const path = require("path");
const appRoot = require('app-root-path');
const decrypter = require(appRoot.path+"/helperfunctions/password-decrypter");
const {permissionThatUserShouldHave} = require('./user.permission');
const _mechid = process.env.MECHID || '';
const isPasswordEncrypted = process.env.IS_PASSWORD_ENCRYPTED || "notEncrypted";
var _password
if(isPasswordEncrypted === "encrypted") {
    const _encrypted_password = process.env.MECHID_PASSWORD || '';
    _password = decrypter(_encrypted_password, appRoot.path+'/secrets/mechid_password_key.pem');
}
else {
    _password = process.env.MECHID_PASSWORD || '';
}


const prop = {
    permissionThatUserShouldHave,
    frameWork : 'express', // Select FramWork hapi or express.
    env : 'dev', // Select env prod or dev.
    secretKey : 'test', // assign a secretKey that will be used to validate when a token is created.
    expTokenIn : 5, // Set Token expiration in minutes. For this example we have set the token to expire in 5 minutes.
    macid : _mechid,
    password : _password,
    limitNumberOfHits: 150, // Allow 150 requests per hour
    limitTimeFrame: 'hour' // Also understands 'second', 'minute', 'hour', 'day', or a number of milliseconds
}

module.exports = {prop}