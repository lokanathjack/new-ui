const getPort = require('get-port');


let portdynamic;

getPort(3000).then((port) => {
    portdynamic = port;
});

module.exports = portdynamic;

