'use strict';

var util = require('util');
var commonNames = require('./commonNames.js');
const logger= require('@com.att.ajsc/1t-logging').logger;
const appRoot = require('app-root-path');
//const configuration = require(appRoot.path+'/config/override-configs.json');
//------------
const path = require('path');
const fs = require('fs');
const rimraf = require('rimraf');
var configuration;
const dirExist = fs.existsSync(path.resolve(process.cwd(),'config-map'));
const configDirExist = fs.existsSync(path.resolve(process.cwd(),'config'));

if (dirExist) {
    if (configDirExist) {
        rimraf(path.resolve(process.cwd(),'config'),function (err) {
            if (err) {
                logger.info('config folder is not found, it may removed already');
            }else {
                logger.info('config folder removed');
            }
        });
    }
    configuration = require(path.resolve(process.cwd(),'./config-map/override-configs.json'));
}else {
    (function (dir) {
        try {
            fs.statSync(dir);
            logger.info('config-map dir is not exist, config dir exists');
            //console.log('getting configurations from config folder...');
            configuration = require(path.resolve(process.cwd(),'./config/override-configs.json'));
        } catch (e) {
            //console.log('could not get config from config folder');
        }
    })('config');
}
//---------

module.exports = function(options) {
    options = options || {};

    if(typeof options !== 'object') {
        throw new Error(commonNames.ErrorMessages.InvalidOptionsError);
    }

    var addChecks = options.addChecks || function (fail, pass) {
            let checkDBConnection = function(){
                //here check your db connection and return info as JSON object.
                return null;
            }
            //by default dbConnectionInfo setting to {"dbConnectionStatus": "success"} for example.
            let dbConnectionInfo = checkDBConnection() || {"dbConnectionStatus": "success"};
            if(dbConnectionInfo) {
                pass({"dbConnectionStatus": "success"});
            }
            else{
                fail(new Error('could not connect to database'));
            }
        };

    var healthInfo = options.healthInfo || function (passInfo) {
            return passInfo;
        };

    if(typeof addChecks !== 'function') {
        throw new Error(util.format('%s: %s', commonNames.ErrorMessages.FunctionError, 'addChecks'));
    }

    if(typeof healthInfo !== 'function') {
        throw new Error(util.format('%s: %s', commonNames.ErrorMessages.FunctionError, 'healthInfo'));
    }

    return function(req, res) {
        try {
            addChecks(onFail, onPass);
        } catch(err) {
            onFail(err);
        }

        function onFail(err) {
            var failureInfo = {
                status: commonNames.Status.Failure
            };

            if(err) {
                failureInfo.message = err.message;
            }
            if(configuration.server  === 'express') {
                res.status(500).json(failureInfo);
            }
            if(configuration.server  === 'hapi') {
                res(failureInfo);
            }
        }

        function onPass(passInfo) {
            passInfo = passInfo || {};
            passInfo.status = passInfo.status || commonNames.Status.Success;
            passInfo.uptime = passInfo.uptime || process.uptime();
            passInfo.memoryUsage = passInfo.memoryUsage || process.memoryUsage();

            var info;
            try {
                info = healthInfo(passInfo) || {};

                if(typeof info !== 'object') {
                    info = { message: info.toString() };
                }

            } catch(err) {
                info = {
                    status: commonNames.Status.Success,
                    warning: util.format('%s: %s', commonNames.ErrorMessages.HealthInfoError, err.message)
                };
            }


            if(configuration.server  === 'express') {
                res.status(200).json(info);
            }
            if(configuration.server  === 'hapi') {
                  res(info);
            }
        }
    };
};