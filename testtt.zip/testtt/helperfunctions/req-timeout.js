/**
 * Created by rx226f on 1/15/2018.
 */
module.exports = function timeout(ms) {
    ms = ms || 5000;
        return function(req, res, next) {
        req.headers.timeOutTime = ms;
        var id = setTimeout(function() {
            req.timeout = true;
            req.emit('timeout', ms);
        }, ms);

        req.on('timeout', function() {
            if (res.headerSent) return debug('response started, cannot timeout');
            var err = new Error('Response timeout');
            err.timeout = ms;
            err.status = 503;
            next(err);
        });

        req.clearTimeout = function() {
            clearTimeout(id);
        };

        req.resetTimeout = function(newMs) {
            clearTimeout(id);
            id = setTimeout(function() {
                req.emit('timeout', newMs);
            }, newMs);
        };

        res.on('finish', function() {
            clearTimeout(id);
        });
                next();
    };
};