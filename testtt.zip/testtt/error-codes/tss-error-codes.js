const commonNames = require('../helperfunctions/commonNames.js');

/*
 Service Exceptions – These exceptions occur when a service is unable to
 process a request and retrying the request will result in a consistent
 failure (e.g., an application provides invalid input).

 Policy Exceptions – These exceptions occur when a policy criteria has not
 been met (e.g., the (N+1)th request arrives when an application’s service
 level agreement only allows N transactions per time interval).

 TSS Exceptions
 3000 to 9999 are available for exceptions.
 */

function TSSError(errorType, messageId, text, variables, url) {
    this.errorType = errorType;
    this.messageId = messageId;
    this.text = text;
    this.variables = variables;
    this.url = url;
}
TSSError.prototype = Object.create(Error.prototype);


/*
 TSS Service Exceptions
 3000 to 6499 are available for service exceptions.
 */
function InvalidInput(text, variables, url) {
    TSSError.call(this, commonNames.SERVICE_EXCEPTION, 'SVC3000', text, variables, url);
}
InvalidInput.prototype = Object.create(TSSError.prototype);


/*
 TSS Policy Exceptions
 6500 to 9000 are available for policy exceptions.
 */
function ExceedsReqPerMin(text, variables, url) {
    TSSError.call(this, commonNames.POLICY_EXCEPTION, 'POC6500', text, variables, url);
}
ExceedsReqPerMin.prototype = Object.create(TSSError.prototype);



exports.TSSError = TSSError;
exports.InvalidInput = InvalidInput;
exports.ExceedsReqPerMin = ExceedsReqPerMin;




