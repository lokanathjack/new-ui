/**
 * Created by rx226f on 11/28/2017.
 */
const chai = require('chai');
const expect = require('chai').expect;
chai.use(require('chai-http'));
const appRoot = require('app-root-path');
    const app = require(appRoot.path+'/src/server/app.js');
var tools = require(appRoot.path+'/helperfunctions/tools.js');


// describe('API endpoint'+tools.getUrlPrefix()+'/v1/helloworld', function() {
//     this.timeout(5000); // How long to wait for a response (ms)
//     before(function() {
//
//     });
//     after(function() {
//
//     });
//     it('helloworld route should return status code 200', function() {
//         return chai.request(app)
//             .get(tools.getUrlPrefix()+'/v1/helloworld')
//             .then(function(res) {
//                 expect(res).to.have.status(200);
//             });
//     });
// });

describe('API endpoint'+tools.getUrlPrefix()+'/v1/example', function() {
    this.timeout(5000); // How long to wait for a response (ms)
    before(function() {

    });
    after(function() {

    });
    it('example route should return status code 200', function() {
        return chai.request(app)
            .get(tools.getUrlPrefix()+'/v1/example')
            .then(function(res) {
                expect(res).to.have.status(200);
            });
    });
});

// describe('API endpoint'+tools.getUrlPrefix()+'/v1/metrics', function() {
//     this.timeout(5000); // How long to wait for a response (ms)
//     before(function() {
//
//     });
//     after(function() {
//
//     });
//     it('metrics route should return status code 200', function() {
//         return chai.request(app)
//             .get(tools.getUrlPrefix()+'/v1/metrics')
//             .then(function(res) {
//                 expect(res).to.have.status(200);
//             });
//     });
// });

// describe('API endpoint'+tools.getUrlPrefix()+'/v1/login', function() {
//     this.timeout(5000); // How long to wait for a response (ms)
//     before(function() {
//
//     });
//     after(function() {
//
//     });
//     it('login route should return status code 200', function() {
//         return chai.request(app)
//             .get(tools.getUrlPrefix()+'/v1/login')
//             .then(function(res) {
//                 expect(res).to.have.status(200);
//             });
//     });
// });

// describe('API endpoint'+tools.getUrlPrefix()+'/v1/login', function() {
//     this.timeout(5000); // How long to wait for a response (ms)
//     before(function() {
//
//     });
//     after(function() {
//
//     });
//     it('login route should return status code 200', function() {
//         return chai.request(app)
//             .get(tools.getUrlPrefix()+'/v1/login')
//             .then(function(res) {
//                 expect(res).to.have.status(200);
//             });
//     });
// });

describe('API endpoint'+tools.getUrlPrefix()+'/v1/healthcheck', function() {
    this.timeout(5000); // How long to wait for a response (ms)
    before(function() {

    });
    after(function() {

    });
    it('healthcheck route should return status code 200', function() {
        return chai.request(app)
            .get(tools.getUrlPrefix()+'/v1/healthcheck')
            .then(function(res) {
                expect(res).to.have.status(200);
            });
    });
});

// describe('API endpoint'+tools.getUrlPrefix()+'/v1/tssexceptiondemo/serviceError', function() {
//     this.timeout(5000); // How long to wait for a response (ms)
//     before(function() {
//     });
//     after(function() {
//
//     });
//     it('tssexceptiondemo/serviceError route should return json error message', function() {
//         return chai.request(app)
//             .post(tools.getUrlPrefix()+'/v1/tssexceptiondemo/serviceError')
//             .send({
//                 "username":"ram maradolla",
//                 "password":"password",
//                 "email":"ram131@gmail.m"
//             })
//             .then(function(res) {
//                 expect(res).to.have.status(200);
//                 expect(res.body).to.be.an('object');
//             });
//     });
// });