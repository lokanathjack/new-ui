const Lab = require('lab');
const Code = require('code');
var path=require('path');
const appRoot = require('app-root-path');

    const server = require(appRoot.path+'/src/server/app.js');
const lab = exports.lab = Lab.script();

lab.test('/helloworld route', (done) => {
    server.inject({method: 'GET', url: '/helloworld'}, (res) => {
    Code.expect(res.statusCode,'status code from /helloworld').to.equal(302);
    // Code.expect(res.result,'Return message from /helloworld').to.equal('helloworld Route POST method');
    console.log("Response code is : ",res.statusCode);
        done()
    });
});