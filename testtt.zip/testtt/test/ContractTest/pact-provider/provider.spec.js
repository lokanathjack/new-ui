
//New PACT Changes

const verifier = require('pact').Verifier;
const pact = require('pact');
const path = require('path');
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
const appRoot = require('app-root-path');
const expect = chai.expect;
// const {server} = require('../server');
chai.use(chaiAsPromised)

var pblookup=require(appRoot.path+'/test/ContractTest/NgnixInvoker.js');
    const {server} = require(appRoot.path+'/src/server/app.js');

chai.use(chaiAsPromised);

var pburl;
const runPactProviderTest = function (server) {
pblookup.pactBrokerLookup(function(pburl)
    {
       console.log("pact borker url is : " +pburl);
       const opts = {
    provider: 'HelloworldANSC7 Provider',
    providerBaseUrl: 'http://localhost:8096', // Give it a port your server is running on
    // providerStatesUrl: 'http://localhost:8081/states',
    // providerStatesSetupUrl: 'http://localhost:8000/setup',
   // pactBrokerUrl: 'http://zld03739.vci.att.com'

    pactBrokerUrl: 'http://'+ pburl+'/', //'http://zlp22234.vci.att.com:30120/',

    pactBrokerUsername: 'pactadmin',
    pactBrokerPassword: 'pactadmin'    // pactUrls: [path.resolve(process.cwd(),'./pacttest/consumer/test/pacts/aaf_consumer-aaf_provider.json')]
    }

      return verifier.verifyProvider(opts)
        .then((output) => {
            console.log('')
            console.log('Pact Verification Complete!');
            console.log(output);
            server.stop({ timeout: 10000 }).then(function (err) {
                     console.log('express server stopped');
                if (err) {
                    console.log('error stopping hapi server');
                    process.exit((err) ? 1 : 0)
                }
            })

        }).catch((error) => {
            console.log(error)
            server.stop({ timeout: 10000 }).then(function (err) {
                console.log('express server stopped');
                if (err) {
                    console.log('error stopping hapi server');
                    process.exit((err) ? 1 : 0)
                }
            })
        })
 
    })
};

module.exports = {runPactProviderTest};