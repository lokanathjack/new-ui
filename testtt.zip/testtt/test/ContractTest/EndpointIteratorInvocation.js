var DME2EndpointIterator = require("@com.att.adf/dme2-nodejs/lib/util/DME2EndpointIterator.js");
var DME2manager =require("@com.att.adf/dme2-nodejs/lib/model/DME2manager.js");
var DME2UniformResource=require('@com.att.adf/dme2-nodejs/lib/model/DME2UniformResource.js');
var DME2Proximity=require('@com.att.adf/dme2-nodejs/lib/model/DME2Proximity.js');
var logger=require("@com.att.adf/dme2-nodejs/lib/util/loggingConfigurationService.js");
var PropertiesReader = require('properties-reader');
var path=require('path');
var http = require('http');
var defaultProp = PropertiesReader('./node_modules/@com.att.adf/dme2-nodejs/conf/defaultConfig.properties');
//Please update with path of External Configuration File
var clientProp = PropertiesReader(path.join(__dirname,'./dme2Config.properties'));
//client need to specify the path of client config property file if not use the defaulprop
var clientProp;
if (clientProp===undefined){
 
 clientProp=defaultProp;
}
var manager;
var iterator;
var timeout;
var endpoints = [];
var endpointsGRM = [];
var distanceBandsArray=[];
logger.init(defaultProp);
EndpointIteratorInvocation=function(serviceName,version,envContext,routeOffer,callback){
    var serviceName = serviceName;
    var version = version;
    var envContext = envContext;
    var routeOffer = routeOffer;
    var it;
    var latitudeDegrees=getProperty("AFT_LATITUDE");
    var longitudeDegrees=getProperty("AFT_LONGITUDE");
    var distanceCacheSize=getProperty("DISTANCE_CACHE_SIZE");
    var isExcludingOutOfBandEndpoints=getProperty("DME2_ENDPOINT_BANDS_EXCLUDE_OUT_OF_BAND");
    var clientURI='http://'+serviceName+'/version='+version+'/envContext='+envContext+'/routeOffer='+routeOffer;
    console.log("EndpointIteratorInvocation:calling getenponitsRO starts");
    var uniformResource=new DME2UniformResource(clientProp,clientURI);
    manager=new DME2manager(clientProp,uniformResource);
    var promise = manager.initRegistry();
       
    manager.proximityAide=  new DME2Proximity(latitudeDegrees, longitudeDegrees, distanceCacheSize, [.1,500,5000], isExcludingOutOfBandEndpoints);
    iterator=new DME2EndpointIterator(clientURI,manager);
    promise.then(function (value){
          
         iterator.getEndpointswithRO().then(function (value){
         //This value variable has end point details of desire service
         console.log("EndpointIteratorInvocation value in iterator resolved: ",value);
         console.log("EndpointIteratorInvocation Promise Resolved in Generator");
         callback(value);
                
       }).catch(function (error){
         console.log('EndpointIteratorInvocation:Promise Rejected error',error);
        });
           
        })
};
   
getProperty = function(key) {
 var value;
 // System Specified
 if (key === 'GRM_PORT') {
  value = process.env.GRM_PORT;
 } else if (key === 'GRM_PROTOCOL') {
  value = process.env.GRM_PROTOCOL;
 } else if (key === 'GRM_DNS') {
  value = process.env.GRM_DNS;
 } else if (key === 'AFT_LATITUDE') {
  value = process.env.AFT_LATITUDE;
 } else if (key === 'AFT_LONGITUDE') {
  value = process.env.AFT_LONGITUDE;
 } else if (key === 'GRM_SERVICE_NAME') {
  value = process.env.GRM_SERVICE_NAME;
 } else if (key === 'GRM_SERVICE_VERSION') {
  value = process.env.GRM_SERVICE_VERSION;
 } else if (key === 'GRM_ENV') {
  value = process.env.GRM_ENV;
 } else {
  value = process.env.key;
 }
 logger.info('EndpointIteratorInvocation:System Specified value for key '+key+' is :'+value);
 // Client Specified
 if (value == null) {
  if (clientProp.get(key) != null) {
   value = clientProp.get(key);
   // console.log('Client Specified value: ',value);
   logger.info('EndpointIteratorInvocation:Client Specified value for key '+key+' is :'+value);
  }
  // Default Value
  else {
   value = defaultProp.get(key);
   // console.log('Default value: ',value);
   logger.info('EndpointIteratorInvocation:Default value for key '+key+' is :'+value);
  }
 }
 return value;
} 
module.exports=EndpointIteratorInvocation;